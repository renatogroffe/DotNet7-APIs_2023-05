# ASPNETCore7-REST_API-SimulacaoHealthCheck_ContagemAcessos
Exemplo de API REST para contagem de acessos criada com .NET 7 + ASP.NET Core, com um Controller simulando um endpoint de Health Check. Inclui Dockerfile para a geração de imagens baseadas em Linux.
